import React, { useState, useEffect } from "react";

function FrameShoulder() {
  return (
    <div className="col-xl-6 ">
      <h3>Shoulder</h3>
      <div className="chart-area border border-dark frame"></div>
    </div>
  );
}

export default FrameShoulder;
