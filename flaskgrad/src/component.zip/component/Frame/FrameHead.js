import React, { useState, useEffect } from "react";

function FrameHead() {
  return (
    <div className="col-xl-6 ">
      <h3>Head</h3>
      <div className="chart-area border border-dark frame"></div>
    </div>
  );
}

export default FrameHead;
