import React, { useState, useEffect } from "react";

function FrameHip() {
  return (
    <div className="col-xl-6">
      <h3>Hip</h3>
      <div className="chart-area border border-dark frame"></div>
    </div>
  );
}

export default FrameHip;
